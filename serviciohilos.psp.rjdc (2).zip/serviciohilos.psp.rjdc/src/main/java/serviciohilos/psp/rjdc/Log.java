package serviciohilos.psp.rjdc;

import java.io.IOException;
import java.util.logging.*;

public class Log {
    private static final Logger logger = Logger.getLogger(Log.class.getName());
    private FileHandler fileHandler;

    public Log(String logFileName) {
        try {
           
            fileHandler = new FileHandler(logFileName);
            logger.addHandler(fileHandler);
            logger.setLevel(Level.ALL); 
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);
        } catch (IOException e) {
            System.err.println("Error creating logger: " + e.getMessage());
        }
    }

    public void logConnection(String message) {
        logger.info(message);
    }

    public void logError(String message, Throwable throwable) {
        logger.log(Level.SEVERE, message, throwable);
    }

    public void closeLogger() {
        if (fileHandler != null) {
            fileHandler.close();
        }
    }
}
