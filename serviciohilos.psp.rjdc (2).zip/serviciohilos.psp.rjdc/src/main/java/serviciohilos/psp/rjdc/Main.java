package serviciohilos.psp.rjdc;

public class Main {

	public static void main(String[] args) {
		
		
		SocketConexion sc = new SocketConexion();
				
		try {
			
			sc.conexion();

		}catch (Exception e) {
			
			System.out.println(e);
			// TODO: handle exception
		}
		

	}

}
