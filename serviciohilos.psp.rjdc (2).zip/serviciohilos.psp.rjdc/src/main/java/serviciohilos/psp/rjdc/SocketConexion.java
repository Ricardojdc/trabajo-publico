package serviciohilos.psp.rjdc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketConexion {

	private int puerto = 2024;
	
	/**
	 * Función de conexión del socket
	 */

	public void conexion() {

		try (ServerSocket serverSocket = new ServerSocket(puerto)) {
			System.out.println("Servidor en puerto: " + puerto);

			while (true) {

				Socket clientSocket = serverSocket.accept();
				clientSocket.setSoTimeout(50000);
				System.out.println("Cliente conectado: " + clientSocket.getInetAddress());

				Thread clientThread = new Thread(() -> clienteHilo(clientSocket));
				clientThread.start();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Función que maneja el evento asociado a la creación del hilo
	 * @param clienteSocket Socket asociado a la conexión que acaba de aceptar
	 */

	private static void clienteHilo(Socket clienteSocket) {
		try {

			MongoServicio ms = new MongoServicio();
			
			ms.conectar("tickets", "tickets", ms.getUri());
			

			BufferedReader reader = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));

			String linea = reader.readLine();

			if (linea.length() <= 1024) {

				String[] reserva;

				reserva = linea.split(",");

				if (reserva.length == 2) {

					if (reserva[0].equals("TK")) {

						ms.actualizarEstado(ms.getCollection(), reserva[1]);
						

					}

				} else {

					System.out.println("Numero de parámetros incorrectos");
				}

			} else {

				System.out.println("El tamaño del mensaje supera la cantidad máxima");
			}

			reader.close();
			clienteSocket.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private synchronized void insertar() {

	}

}