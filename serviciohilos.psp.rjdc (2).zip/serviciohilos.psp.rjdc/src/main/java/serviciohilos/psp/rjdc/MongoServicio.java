package serviciohilos.psp.rjdc;

import java.util.Scanner;
import java.util.function.Consumer;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoServicio {

	private MongoClient client;
	private MongoDatabase db;
	private MongoCollection<Document> collection;
	
	
	// Cadenas oara diferentes servidores
	
	private String uri = "mongodb://ricardoAcceso:ricardo12345@158.179.223.124:27017/"; // 158.179.223.124
	//private String uri = "mongodb://new_user:new_password@localhost:27017";

	/**
	 * Función para la conexión a una base de datos MongoDB mediante un nombre de base de datos y colección especifica
	 *
	 * @param database  Nombre de la base de datos a la que se va a acceder
	 * @param coleccion Nombre de la colección a la que vamos a acceder
	 * @param uri       Cadena de conexión de la base de datos
	 */

	void conectar(String database, String coleccion, String uri) {

		client = MongoClients.create(uri);
		db = this.client.getDatabase(database);
		collection = db.getCollection(coleccion);

	}

	/**
	 * 
	 * @param c Nombre de la colleción a la que se va a acceder
	 * @param nombre Nombre que se va a guardar en el documento
	 */
	
	
	synchronized void actualizarEstado(MongoCollection<Document> c, String nombre) {
		  Document queryCheck = new Document("ocupado", false);
	        long count = c.countDocuments(queryCheck);
	        if (count > 0) {
	           
	            Document query = new Document("ocupado", false);
	            Document update = new Document("$set", new Document("ocupado", true).append("nombre", nombre));
	            c.updateOne(query, update);
	        } else {
	            System.out.println("No quedan sitios");
	        }
	    }
	

	public MongoClient getClient() {
		return client;
	}

	public void setClient(MongoClient client) {
		this.client = client;
	}

	public MongoDatabase getDb() {
		return db;
	}

	public void setDb(MongoDatabase db) {
		this.db = db;
	}

	public MongoCollection<Document> getCollection() {
		return collection;
	}

	public void setCollection(MongoCollection<Document> collection) {
		this.collection = collection;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}