package hb.ac.rjdc;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Main {

	/**
	 * Función para imprimir el menú
	 * 
	 * @return Devuelve el valor seleccinado
	 */

	public static int menu() {

		System.out.println("\n1-Insertar dato\n2-Buscar dato\n3-Modificar dato\n4-Borrar dato\n5-Salir");

		Scanner sc = new Scanner(System.in);
		boolean salida = false;
		int opcion;

		do {
			System.out.println("\n\nIntroduzca opción: ");
			opcion = Integer.parseInt(sc.nextLine());

			if (opcion > 0 && opcion < 6)
				salida = true;

		} while (salida == false);

		return opcion;
	}

	/**
	 * Función de insercción de datso
	 * 
	 * @param s Session actual de hibernate
	 */
	public static void insertar(Session s) {
		
		s.beginTransaction();

		Scanner sc = new Scanner(System.in);

		System.out.println("Introduce el nombrelogin, password y nombrecompleto");
		String nombreLogin = sc.nextLine();
		String pass = sc.nextLine();
		String nombreCompleto = sc.nextLine();

		Cliente c = new Cliente();
		c.setNombreLogin(nombreLogin);
		c.setPassword(pass);
		c.setNombreCompleto(nombreCompleto);
		
		

		s.save(c);
		s.getTransaction().commit();

	}

	/**
	 * Funcion de consulta
	 * 
	 * @param s Session actual de hibernate
	 */

	public static <T> T consultar(Session s, Class<T> clase) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Introduce el nombrelogin para la busqueda: ");
		String nombreLogin = sc.nextLine();
		
		Cliente ret = null;
		
		String hql = "FROM "+ clase.getSimpleName();
		Query query = s.createQuery(hql);

		List<Cliente> clientes = query.list();

		for (Cliente cliente : clientes) {

			if (cliente.getNombreLogin().equals(nombreLogin)) {
				System.out.println("NombreLogin: " + cliente.getNombreLogin() + "\nPassword: " + cliente.getPassword()
						+ "\nNombre Completo: " + cliente.getNombreCompleto());
				
				ret = cliente;
				
				
			}
		}
		return (T) ret;

	}
	
	/**
	 * Función para la modificación de una fila
	 * @param s Se pasa por parametro la sesión actual de Hibernate
	 */
	
	public static void update(Session s) {
		
		s.beginTransaction();

		Scanner sc = new Scanner(System.in);

		Cliente aux = consultar(s, Cliente.class);
		if (aux != null) {
		System.out.println("Introduce el nuevo nombre de login");
		String nombreLoginNuevo = sc.nextLine();
		
		Cliente c = s.get(Cliente.class,aux.getId());
		
		c.setNombreLogin(nombreLoginNuevo);
	
		s.getTransaction().commit();
		}else {
			
			System.out.println("No se ha podido modificar ningún valor");
		}
			
	}
	
	/**
	 * Función de borrado de la sesisión de hibernate
	 * @param s Se pasa la sesión de hibernate actual
	 */
	
	
	public static void borrar(Session s) {
		
		s.beginTransaction();
		
		 	Object c = consultar(s,Cliente.class);
		 	
		 	if(c != null) {
		 		
		 		s.delete(c);
		 		
		 	}else {
		 		
		 		System.out.println("No se ha podido borrar - no se ha encontrado ninguna coincidencia");
		 	}
		    
		    
		    s.getTransaction().commit();
		
		
	}
	

	public static void main(String[] args) {

		// Carga del fichero de configuración
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		// Creación de la sesión entre JAVA e Hibernate
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();

		// Comienzo de la transacción SQL
		

		boolean pararPrograma = false;

		do {

			switch (menu()) {

			case 1:

				insertar(session);

				break;

			case 2:

				
				Object c = consultar(session,Cliente.class);
				if((Cliente)c == null) {
					
					System.out.println("No se ha encontrado cliente");
				}
	
				break;

			case 3:

				update(session);
				
				break;

			case 4:
				
				borrar(session);

				break;

			case 5:

				pararPrograma = true;

				break;
			}
		} while (pararPrograma == false);

		// Cierre de la sesión

		
		session.close();

	}

}
