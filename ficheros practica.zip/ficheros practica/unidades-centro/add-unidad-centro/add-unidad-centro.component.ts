import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UnidadCentro } from 'src/app/shared/interfaces/unidades-centro';
import { INVALID_FORM, CLOSE } from '../../shared/messages';
import { UnidadesCentroService } from 'src/app/services/unidades-centro.service';


@Component({
  selector: 'app-add-unidad-centro',
  templateUrl: './add-unidad-centro.component.html',
  styleUrls: ['./add-unidad-centro.component.scss']
})
export class AddUnidadCentroComponent implements OnInit {


  unidadCentroForm: FormGroup;

  constructor(public dialogRef: MatDialogRef<AddUnidadCentroComponent>,
              private snackBar: MatSnackBar,
              private servicioUnidadesCentro: UnidadesCentroService
  ) {

  }

  ngOnInit() {
    this.unidadCentroForm = new FormGroup({
      unidadCentro: new FormControl(null, Validators.required),
      idCiclo: new FormControl(null,Validators.required), //Linea nueva
      observaciones: new FormControl(null)
    });
  }

  async confirmAdd() {
    if (this.unidadCentroForm.valid) {
      const unidadCentro = this.unidadCentroForm.value as UnidadCentro;

      const RESP = await this.servicioUnidadesCentro.addUnidadCentro(unidadCentro).toPromise();
      if (RESP.ok) {
        this.snackBar.open(RESP.message, CLOSE, { duration: 5000 });
        this.dialogRef.close({ok: RESP.ok, data: RESP.data});
      } else {
        this.snackBar.open(RESP.message, CLOSE, { duration: 5000 });
      }
    } else {
      this.snackBar.open(INVALID_FORM, CLOSE, { duration: 5000 });
    }
  }

  onNoClick() {
    this.dialogRef.close({ok: false});
  }
}
