import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatosUnidadesCentroComponent } from './datos-unidades-centro.component';
import { CrudMaterialModule } from '../../modules/crud-material/crud-material.module'
import { DatosUnidadesCentroRoutingModule } from './datos-unidades-centro-routing.module';
import { AlumnosModule } from 'src/app/alumnos/alumnos.module';
import { AddAlumnoModule } from 'src/app/alumnos/add-alumno/add-alumno.module';
import { DeleteAlumnoModule } from 'src/app/alumnos/delete-alumno/delete-alumno.module';
import { EditAlumnoModule } from 'src/app/alumnos/edit-alumno/edit-alumno.module';
import { AlumnosUnidadesCentroRoutingModule } from './alumnos-unidades-centro/alumnos-unidades-centro-routing.module';



@NgModule({
  declarations: [DatosUnidadesCentroComponent],
  imports: [
    CommonModule,
    CrudMaterialModule,
    DatosUnidadesCentroRoutingModule,
    AlumnosUnidadesCentroRoutingModule,
    AlumnosModule,
    AddAlumnoModule,
    DeleteAlumnoModule,
    EditAlumnoModule,
  ]
})
export class DatosUnidadesCentroModule { }
