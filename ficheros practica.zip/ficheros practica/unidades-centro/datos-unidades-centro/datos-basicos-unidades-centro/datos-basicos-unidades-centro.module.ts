import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatosBasicosUnidadesCentroComponent } from './datos-basicos-unidades-centro.component';
import { CrudMaterialModule } from 'src/app/modules/crud-material/crud-material.module';
import { DatosBasicosUnidadesCentroRoutingModule } from './datos-basicos-unidades-centro-routing.module';



@NgModule({
  declarations: [DatosBasicosUnidadesCentroComponent],
  imports: [
    CommonModule,
    CrudMaterialModule,
    DatosBasicosUnidadesCentroRoutingModule,

  ]
})
export class DatosBasicosUnidadesCentroModule { }
