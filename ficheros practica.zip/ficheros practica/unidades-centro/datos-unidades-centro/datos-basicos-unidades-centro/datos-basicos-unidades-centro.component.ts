import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ENTIDAD_UNIDAD_CENTRO } from 'src/app/shared/messages';
import { DatosUnidadesCentroComponent } from '../datos-unidades-centro.component';
import { UnidadesCentroService } from 'src/app/services/unidades-centro.service';
import { UnidadCentro } from 'src/app/shared/interfaces/unidades-centro';
import { CiclosService } from 'src/app/services/ciclos.service';
import { Ciclo } from 'src/app/shared/interfaces/ciclo';

@Component({
  selector: 'app-datos-basicos-unidades-centro',
  templateUrl: './datos-basicos-unidades-centro.component.html',
  styleUrls: ['./datos-basicos-unidades-centro.component.scss']
})
export class DatosBasicosUnidadesCentroComponent implements OnInit {

  datosBasicosForm: FormGroup;
  unidadesCentro: UnidadCentro;
  ciclos: Ciclo[]


  //ENTIDAD: String;

  constructor(
    private datosUnidadCentro: DatosUnidadesCentroComponent,
    public unidadesCentroService: UnidadesCentroService,
    private cicloService : CiclosService
  ) {


    this.unidadesCentro = datosUnidadCentro.datosEditarUnidadCentro; // PALO IMPORTANTE

  }

  ngOnInit(): void {
    //this.ENTIDAD = ENTIDAD_UNIDAD_CENTRO;
    this.setForm();
    this.getCiclos();
    this.datosBasicosForm.valueChanges.subscribe(form => {

      const cicloEncontrado = this.ciclos.find(ciclo => ciclo.id_ciclo === form.id_ciclo);
      // Asigna el nombre del ciclo
      form.ciclo = cicloEncontrado ? cicloEncontrado.ciclo : ''
      this.unidadesCentroService.setDatosBasicosUnidadesCentro(form);
    });

  }

  setForm(): void {
/*
    console.log(this.unidadesCentroService.unidades.unidad_centro)
    console.log(this.unidadesCentro.unidad_centro)*/


    this.datosBasicosForm = new FormGroup({

     id_unidad_centro: new FormControl(this.unidadesCentroService.unidades.id_unidad_centro, Validators.required),
     unidad_centro: new FormControl(this.unidadesCentroService.unidades.unidad_centro, Validators.required),
     id_ciclo: new FormControl(this.unidadesCentroService.unidades.id_ciclo, Validators.required),
     observaciones: new FormControl(this.unidadesCentroService.unidades.observaciones)

    });
  }

  async getCiclos() {
    const RESPONSE = await this.cicloService.getAllCiclos().toPromise();
    //this.permises = RESPONSE.permises;

    if (RESPONSE.ok) {
      this.ciclos = RESPONSE.data as Ciclo[];
    }
  }
}
