import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlumnosUnidadesCentroComponent } from './alumnos-unidades-centro.component';

const routes: Routes = [{
    path: '',
    component: AlumnosUnidadesCentroComponent
}]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AlumnosUnidadesCentroRoutingModule { }
