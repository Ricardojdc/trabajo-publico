import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlumnosUnidadesCentroComponent } from './alumnos-unidades-centro.component';
import { AddAlumnoComponent } from './add-alumno/add-alumno.component';
import { EditAlumnoComponent } from './edit-alumno/edit-alumno.component';
import { DeleteAlumnoComponent } from './delete-alumno/delete-alumno.component';
import { AlumnosUnidadesCentroRoutingModule } from './alumnos-unidades-centro-routing.module';
import { CrudMaterialModule } from 'src/app/modules/crud-material/crud-material.module';
import { FechaPipe } from 'src/app/pipes/fecha.pipe';
import { LinkedinUrlValidatorPipe } from 'src/app/pipes/linkedin.pipe';



@NgModule({
  declarations: [AlumnosUnidadesCentroComponent, AddAlumnoComponent, EditAlumnoComponent, DeleteAlumnoComponent, FechaPipe,LinkedinUrlValidatorPipe],
  imports: [
    CommonModule,
    AlumnosUnidadesCentroRoutingModule,
    CrudMaterialModule,

  ]
})
export class AlumnosUnidadesCentroModule { }
