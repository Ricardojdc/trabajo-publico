/* import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-unidad-centro',
  templateUrl: './delete-unidad-centro.component.html',
  styleUrls: ['./delete-unidad-centro.component.scss']
})
export class DeleteUnidadCentroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

} */


import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CLOSE } from '../../shared/messages';
import { UnidadCentro } from 'src/app/shared/interfaces/unidades-centro';
import { UnidadesCentroService } from 'src/app/services/unidades-centro.service';

@Component({
  selector: 'app-delete-unidad-centro',
  templateUrl: './delete-unidad-centro.component.html',
  styleUrls: ['./delete-unidad-centro.component.scss']
})
export class DeleteUnidadCentroComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DeleteUnidadCentroComponent>,
              @Inject(MAT_DIALOG_DATA) public unidadCentro: UnidadCentro,
              private servicioUnidadCentro: UnidadesCentroService,
              private snackBar: MatSnackBar
  ) { }

  ngOnInit() {
  }

  async deleteUnidadCentro() {
    const RESP = await this.servicioUnidadCentro.deleteUnidad(this.unidadCentro.id_unidad_centro).toPromise();
    if (RESP.ok) {
      this.snackBar.open(RESP.message, CLOSE, { duration: 5000 });
      this.dialogRef.close({ok: RESP.ok, data: RESP.data});
    } else {
      this.snackBar.open(RESP.message, CLOSE, { duration: 5000 });
    }
  }

  onNoClick() {
    this.dialogRef.close({ok: false});
  }

}

