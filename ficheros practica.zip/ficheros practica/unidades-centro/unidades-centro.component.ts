import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { FormControl } from '@angular/forms';
import { Permises } from '../shared/interfaces/api-response';
import { UnidadesCentroService } from '../services/unidades-centro.service';
// import { AddUnidadComponent } from './add-unidad/add-unidad.component';
// import { EditUnidadComponent } from './edit-unidad/edit-unidad.component';
// import { DeleteUnidadComponent } from './delete-unidad/delete-unidad.component';
import { SelectionModel } from '@angular/cdk/collections';
import { UnidadCentro } from '../shared/interfaces/unidades-centro';
import { AddUnidadCentroComponent } from './add-unidad-centro/add-unidad-centro.component';
import { EditUnidadCentroComponent } from './edit-unidad-centro/edit-unidad-centro.component';
import { DeleteUnidadCentroComponent } from './delete-unidad-centro/delete-unidad-centro.component';
import { DatosUnidadesCentroComponent } from './datos-unidades-centro/datos-unidades-centro.component';

@Component({
  selector: 'app-unidades-centro',
  templateUrl: './unidades-centro.component.html',
  styleUrls: ['./unidades-centro.component.scss']
})
export class UnidadesCentroComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  dataSource: MatTableDataSource<UnidadCentro> = new MatTableDataSource();


  idUnidadCentroFilter = new FormControl();
  unidadCentro = new FormControl();
  idCiclo = new FormControl();
  observaciones = new FormControl();


  permises: Permises;

  selection: SelectionModel<UnidadCentro>;
  unidad: UnidadCentro;

  displayedColumns: string[];
  private filterValues = { id_unidad_centro: '',unidad_centro: '',id_ciclo: '',observaciones: ''};

  constructor(
    public dialog: MatDialog,
    private unidadesCentroService: UnidadesCentroService,
    private overlay: Overlay
  ) { }

  ngOnInit(): void {
    this.getUnidades();
    //this.getUnidadesCentro();
    //this.createFilter();
    //this.onChanges();
  }


  async getUnidades() {
    const RESPONSE = await this.unidadesCentroService.getAllUnidades().toPromise();
    this.permises = RESPONSE.permises;

    console.log(RESPONSE.data)

    if (RESPONSE.ok) {
      this.unidadesCentroService.unidad = RESPONSE.data as UnidadCentro[];
      //this.displayedColumns = ['id_unidad_centro','unidad_centro','id_ciclo','observaciones','actions'];
      this.displayedColumns = ['unidad_centro','id_ciclo','observaciones','actions'];
      this.dataSource.data = this.unidadesCentroService.unidad;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = this.createFilter();
      this.selection = new SelectionModel<UnidadCentro>(false, [this.unidad]);

      this.onChanges();
    }
  }

  async addUnidadCentro() {
    const dialogRef = this.dialog.open(AddUnidadCentroComponent, { scrollStrategy: this.overlay.scrollStrategies.noop(), disableClose: true });
     const RESULT = await dialogRef.afterClosed().toPromise();
     if (RESULT) {
       if (RESULT.ok) {
         this.unidadesCentroService.unidad.push(RESULT.data);
         this.dataSource.data = this.unidadesCentroService.unidad;
         this.ngOnInit();
       }
     }
  }

  async editUnidadCentro(unidad: UnidadCentro) {
     const dialogRef = this.dialog.open(EditUnidadCentroComponent, { data: unidad, scrollStrategy: this.overlay.scrollStrategies.noop(), disableClose: true });
     const RESULT = await dialogRef.afterClosed().toPromise();
     if (RESULT) {
       if (RESULT.ok) {
         this.unidadesCentroService.editUnidad(RESULT.data);
         this.dataSource.data = this.unidadesCentroService.unidad;
         this.ngOnInit();
       }
     }
  }

  async deleteUnidadCentro(unidad: UnidadCentro) {
     const dialogRef = this.dialog.open(DeleteUnidadCentroComponent, { data: unidad, scrollStrategy: this.overlay.scrollStrategies.noop() });
     const RESULT = await dialogRef.afterClosed().toPromise();
     if (RESULT) {
       if (RESULT.ok) {
         this.unidadesCentroService.deleteUnidad(RESULT.data);
         this.dataSource.data = this.unidadesCentroService.unidad;
         this.ngOnInit();
       }
     }
  }

  async getUnidadesCentro() {
    const RESPONSE = await this.unidadesCentroService.getAllUnidades().toPromise();
    this.permises = RESPONSE.permises;

    console.log(RESPONSE.data)

    if (RESPONSE.ok) {
      this.unidadesCentroService.unidad = RESPONSE.data as UnidadCentro[];
      this.displayedColumns = ['unidad_centro', 'id_ciclo', 'observaciones', 'actions'];
      this.dataSource.data = this.unidadesCentroService.unidad;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = this.createFilter();

      this.onChanges();
    }
  }


  async datosUnidadCentro(unidadCentro: UnidadCentro) {
    const ENTIDAD = unidadCentro;


    if (ENTIDAD) {
      const dialogRef = this.dialog.open(DatosUnidadesCentroComponent, {
        width: '70em',
        maxWidth: '70em',
        scrollStrategy: this.overlay.scrollStrategies.noop(),
        disableClose: true,
        data: ENTIDAD

      });

      const RESULT = await dialogRef.afterClosed().toPromise();
      await this.getUnidades();

    }
  }

  createFilter(): (unidad: UnidadCentro, filter: string) => boolean {
    const filterFunction = (unidad: UnidadCentro, filter: string): boolean => {
      const searchTerms = JSON.parse(filter);

      return unidad.id_unidad_centro.toString().indexOf(searchTerms.id_unidad_centro) !== -1
        && unidad.unidad_centro.toLowerCase().indexOf(searchTerms.unidad_centro.toLowerCase()) !== -1
        && unidad.id_ciclo.toString().indexOf(searchTerms.id_ciclo.toLowerCase()) !== -1
        && unidad.observaciones.toLowerCase().indexOf(searchTerms.observaciones.toLowerCase()) !== -1;

    };

    return filterFunction;
  }

   onChanges() {
    this.idUnidadCentroFilter.valueChanges.subscribe(value => {
        this.filterValues.id_unidad_centro = value;
        this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.unidadCentro.valueChanges
    .subscribe(value => {
        this.filterValues.unidad_centro = value;
        this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.idCiclo.valueChanges
    .subscribe(value => {
        this.filterValues.id_ciclo = value;
        this.dataSource.filter = JSON.stringify(this.filterValues);
    });

    this.observaciones.valueChanges
    .subscribe(value => {
        this.filterValues.observaciones = value;
        this.dataSource.filter = JSON.stringify(this.filterValues);
    });

  }
}
