import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciclos-entidad',
  templateUrl: './ciclos-entidad.component.html',
  styleUrls: ['./ciclos-entidad.component.scss']
})
export class CiclosEntidadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
