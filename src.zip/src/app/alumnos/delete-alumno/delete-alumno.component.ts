import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-alumno',
  templateUrl: './delete-alumno.component.html',
  styleUrls: ['./delete-alumno.component.scss']
})
export class DeleteAlumnoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
