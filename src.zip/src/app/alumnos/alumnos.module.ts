import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AlumnosComponent } from './alumnos.component';
import { AddAlumnoComponent } from './add-alumno/add-alumno.component';
import { EditAlumnoComponent } from './edit-alumno/edit-alumno.component';
import { DeleteAlumnoComponent } from './delete-alumno/delete-alumno.component';
import { CrudMaterialModule } from '../modules/crud-material/crud-material.module';
import { AlumnosUnidadesCentroRoutingModule } from '../unidades-centro/datos-unidades-centro/alumnos-unidades-centro/alumnos-unidades-centro-routing.module';





@NgModule({
  declarations: [AlumnosComponent, AddAlumnoComponent, EditAlumnoComponent, DeleteAlumnoComponent],
  imports: [
    CommonModule,
    AlumnosUnidadesCentroRoutingModule,
    CrudMaterialModule

  ]
})
export class AlumnosModule {





}
