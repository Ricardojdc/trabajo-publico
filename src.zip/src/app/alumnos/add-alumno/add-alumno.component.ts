import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-alumno',
  templateUrl: './add-alumno.component.html',
  styleUrls: ['./add-alumno.component.scss']
})
export class AddAlumnoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
