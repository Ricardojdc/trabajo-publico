import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-alumno',
  templateUrl: './edit-alumno.component.html',
  styleUrls: ['./edit-alumno.component.scss']
})
export class EditAlumnoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
