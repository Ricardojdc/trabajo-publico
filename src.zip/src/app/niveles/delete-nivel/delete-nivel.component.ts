import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-nivel',
  templateUrl: './delete-nivel.component.html',
  styleUrls: ['./delete-nivel.component.scss']
})
export class DeleteNivelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
