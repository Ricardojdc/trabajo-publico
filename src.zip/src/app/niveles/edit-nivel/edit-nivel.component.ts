import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-nivel',
  templateUrl: './edit-nivel.component.html',
  styleUrls: ['./edit-nivel.component.scss']
})
export class EditNivelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
