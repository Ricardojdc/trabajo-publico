import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-nivel',
  templateUrl: './add-nivel.component.html',
  styleUrls: ['./add-nivel.component.scss']
})
export class AddNivelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
