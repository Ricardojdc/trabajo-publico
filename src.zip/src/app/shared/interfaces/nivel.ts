export interface Nivel {
	id_nivel: number;
	nivel: string;
	cod_nivel: string;
	titulo: string;
	observaciones?: any;
  }
  