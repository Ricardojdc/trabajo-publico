import { Opcion } from './opcion';

export interface Navegacion {
  grupo: string;
  opciones: Opcion[];
}
