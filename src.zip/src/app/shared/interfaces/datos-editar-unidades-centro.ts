import { UnidadCentro } from "./unidades-centro";
import { Alumno } from './alumno';

export interface DatosEditarUnidadesCentro {

  unidad_centro: UnidadCentro,
  alumnos: Alumno[]

}
