export interface MotivoReunion {
  id_motivo_reunion: string;
  motivo_reunion: string;
  observaciones?: any;
}
