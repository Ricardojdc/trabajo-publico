export interface UnidadCentro {
	id_unidad_centro: number;
  unidad_centro: string;
  id_ciclo: number;
  observaciones?: any;
  }
