export interface Zona {
	id_zona: string;
	zona: string;
	observaciones?: any;
  }
  