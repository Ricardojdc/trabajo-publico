export interface Opcion {
    id_opcion_menu?: number;
    opcion: string;
    accion: string;
    texto_tooltip: string;
    observaciones?: string;
}
