import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-motivo-nodual',
  templateUrl: './edit-motivo-nodual.component.html',
  styleUrls: ['./edit-motivo-nodual.component.scss']
})
export class EditMotivoNodualComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
